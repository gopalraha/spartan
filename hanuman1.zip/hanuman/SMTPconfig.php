<?php
//Server Address
$SmtpServer="smtp.mailgun.org";
$SmtpPort="587";
$SmtpUser="postmaster@emm.waterindia.co.in";
$SmtpPass="fc0212eb1c8f17ef380562c9dea8e1f7";
?>