<?php 
error_reporting(0);
session_start();

require_once('SMTPconfig.php');
require_once('SMTPClass.php');

$error_flag = 0;
$statusCode = 200;


if ($_SERVER["REQUEST_METHOD"] == "POST") {

	if (empty($_POST["fname"])) {
		$form_errors_array['fname'] = "Name is required";
		$error_flag = 1;
	} else {
		$name = test_input($_POST["fname"]);
		// check if name only contains letters and whitespace
		if (!preg_match("/^[a-zA-Z ]*$/",$name)) {
		  $form_errors_array['fname'] = "Only letters and white space allowed"; 
		  $error_flag = 1;
		}
	}

	if (empty($_POST["email"])) {
		$form_errors_array['email'] = "Email is required";
		$error_flag = 1;
	} else {
		$email = test_input($_POST["email"]);
		// check if e-mail address is well-formed
		if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
		  $form_errors_array['email'] = "Invalid email format"; 
		  $error_flag = 1;
		}
	}


	if (empty($_POST["phone"])) {
		$form_errors_array['phone'] = "Phone is required";
		$error_flag = 1;
	}else {
		$phone = test_input($_POST["phone"]);
		// check if name only contains letters and whitespace
		if (!preg_match("/^[0-9]+$/",$phone)) {
		  $form_errors_array['phone'] = "Only Numbers allowed"; 
		  $error_flag = 1;
		}else if(strlen($_POST["phone"])!=10) {
			$form_errors_array['phone'] = "Mobile number should be ten digits.";
			$error_flag = 1;
		}
	}

	if (empty($_POST["city"])) {
		$form_errors_array['city'] = "city is required";
		$error_flag = 1;
	} else {
		$city = test_input($_POST["city"]);
		// check if name only contains letters and whitespace
		if (!preg_match("/^[a-zA-Z ]*$/",$city)) {
		  $form_errors_array['city'] = "Only letters and white space allowed"; 
		  $error_flag = 1;
		}
	}

	


	if($error_flag==0){

			/*************Start API Integration***************/
		$captured_data= 'Name: '.$name.' ** Email: '.$email.' ** Phone: '.$phone.' ** City: '.$city;
		$utm_source = isset($_GET['utm_source']) ? $_GET['utm_source'] : "";

    	$fields = array(
			'access_token' => urlencode('s2nvm96u6484417m7c0n2rfxst9jnfor'),
			'campaign_code' => urlencode('taksh_banquet'),
			'captured_data' => urlencode($captured_data),
			'utm_source' => urlencode($utm_source)
		);

		//url-ify the data for the POST
		$fields_string = NULL;
		foreach($fields as $key=>$value) { $fields_string .= $key.'='.$value.'&'; }
		rtrim($fields_string, '&');
        
        $ch = curl_init();

		curl_setopt($ch, CURLOPT_URL,"http://www.waterindia.co.in/leadcapture/index.php/api/lead");
		curl_setopt($ch, CURLOPT_POST, count($fields));
		curl_setopt($ch, CURLOPT_POSTFIELDS, $fields_string);

		// Receive server response ...
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

		$server_output = curl_exec($ch);

		curl_close ($ch);

		// Further processing ...
		$response = json_decode($server_output);		

		// if ($response->status == 'success') { 
		// 	echo 'success';
		// } else { 
		// 	echo 'error';
		// }
		/*************End API Integration***************/


		$to  = "techbrown@hotmail.com"; 				
		$from = 'techbrown@hotmail.com'; 
		$fromName = $name; 
		$subject = "Contact form"; 
		$message = "
			Name: $name\n		
			Email: $email\n
			Phone: $phone\n	
			City: $city\n				
			";
		$body = $message;
		
		$response = array('success'=>array('message'=>'success'));
		
		
		$SMTPMail = new SMTPClient ($SmtpServer, $SmtpPort, $SmtpUser, $SmtpPass, $from, $to, $subject, $body);
		$mail = $SMTPMail->SendMail();
		if($mail){
			
			$to  = $email; 				
			$from = 'techbrown@hotmail.com';
			$fromName = 'Jagrut Shree Hanuman Mandir'; 
			$subject = "Thank you"; 
			$message = "Thank you for reaching out ! We will contact you shortly.";
			$body = $message;
			$SMTPMail = new SMTPClient ($SmtpServer, $SmtpPort, $SmtpUser, $SmtpPass, $from, $to, $subject, $body);
			$mail = $SMTPMail->SendMail();
			
			$response = array('success'=>array('message'=>'success'));
			session_destroy();
		}else{
			$response = array('error'=>array('message'=>'error'));
			$statusCode=400;
		}
		
	}else{
		$response = array('error'=>array('error_type'=>'form','errors'=>$form_errors_array));
		$statusCode=400;
	}		
	
}else{
	$response = array('error'=>array('message'=>'error'));
	$statusCode=400;
}

if($statusCode==200){
	echo json_encode($response);
}else{
	header('HTTP/1.1 400 Bad Request');
	header('Content-Type: application/json; charset=UTF-8');
	die(json_encode($response));
}


function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}

?>