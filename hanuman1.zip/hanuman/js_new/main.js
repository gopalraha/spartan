/*----------------Menu-----------------*/
jQuery(document).ready(function() {
	$('.menu4 li').hover(function() {
		//show its submenu
		$('ul', this).slideDown(300);
	}, function() {
		//hide its submenu
		$('ul', this).slideUp(300);
	});

});

$(document).ready(function() {
	$('a#hamburger-navigation').click(function() {
		$('.menu4').slideToggle("slow");
	});

}); 